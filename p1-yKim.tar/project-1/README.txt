Section 1,

Name & Email Address
	Yong Kim - implemented sender.cpp, ctrl+C
	yhkim5719@csu.fullerton.edu
	Seongsoo Hong - implemented sender.cpp, tried extra credit
	seongsoohong@csu.fullerton.edu
	Jason Jose - implemented recv.cpp, designed the program
	jasonisonjose@csu.fullerton.edu
	Jasmine Nguyen - implemented recv.cpp, documentation
	msjas@csu.fullerton.edu

Programming Language:
	C++

Environment:
	Linux / ubuntu / Tuffix

Usage:
	1. ~$ make
	2. ~$ ./sender keyfile.txt
	3. in another terminal
	   ~$ ./recv
	4. if ./recv does not execute well, push
		ctrl+C

Extra Credit:
	Not implemented
